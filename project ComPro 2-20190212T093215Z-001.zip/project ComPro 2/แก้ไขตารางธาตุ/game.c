#include <stdio.h>
#include <time.h>
#define textcolor(txt,back) SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), back*16+txt)    // เป็นฟังชันในการที่ทำให้ตัวหนังสือมีพื้นหลังมีสีต่างๆ
#define resetcolor() SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15)     // เป็นฟังชันในการที่ทำให้ตัวหนังสือมีพื้นหลังมีสีต่างๆ
#include <windows.h>†††         // เป็นฟังชันในการที่ทำให้ตัวหนังสือมีพื้นหลังมีสีต่างๆ
typedef struct{
    int score;
}point;
typedef struct{
    float timee;
}Time;
typedef struct{
    int as;
}ascii;
void fx(char*,int);//1
void fy(char*,char*,int);//2
void fascii(char*,int*);
void table(int);
void fw(int*,char*);
void fww(int*,char*,char*);
int main() {
    fgame();                // ส่งไปให้ฟังชั้น fgame() ในการเลือกว่าจะให้ไปบอกว่าจะเริ่มเกมส์ หรือล้างค่าทั้งหมด
    FILE *game,*no;
    int name[20];
    printf("Input Name: ");         //ให้ผู้เล่นนั้นบรรทึกชื่อ
    scanf("%s",name);               //ให้ผู้เล่นนั้นบรรทึกชื่อ
    system("CLS");                  //ล้างหน้าจอ
    clock_t ti;                     //เป็นการให้โปรแกรมนั้นจับเวลา
    ti = clock();                   //เป็นการให้โปรแกรมนั้นจับเวลา
    float itime[120],timenum=0;      //สร้างตัวแปรเพื่อบรรทึกเวลา
    char in[10],inn[10],im[2],imm[2],m[2],mm[2];
    int se=0,numavg,oavg;
    float avg;
    int check=0,out=0,rann,ran,innum,num=0,score[120],i=0,j,order;

    point tru,fals;     // สร้าง struct เพื่อเก็บคะแนนถูกผิด
    point t,f;      // เก็บคะแนนในกรณีที่ผู้เล่นนั้นเล่นไม่จบ
    FILE *outgame;
    int oorder;


    FILE *orderout,*xxorderout;          // เป็นการที่เปิดไฟล์เอาลำดับของผู้เล่นและค่าเก่าที่ผู้เล่นไม่จบทึเอาไว้ในการที่จะบรรทึกข้อมูลลงไปในไฟล์  gameout
    int xorderout;
    char xxx[108];

    orderout=fopen("orderout.txt","r");  //เปิดไฟล์ orderout เพื่อเอาข้อมูลมาเพื่อเอาค่าลำดับขิงผู้เล่นไม่จบมาเพื่อรอเอาไว้บรรทึกข้อมูล
    fscanf(orderout,"%d",&xorderout);
    oorder=xorderout;
    fclose(orderout);
    int k=99;
    forderr(&k);

    fflush(stdin);                                  // เปิดไฟล์ในกรณีที่ผู้เล่น เล่นไม่จบแล้วมีการออกจากเกมส์ เพื่อเช็งค่าว่าข้างในนั้นมีค่าหรือป่าว
    xxorderout=fopen("xxorderout.txt","r");
    if (xxorderout!=NULL)                               // ถ้าข้างในมีข้อมูลมันจะบรรทึกข้อมูลลงไปอีกไฟล์ นึงเพื่อเก็บข้อมูล
    {
        outgame=fopen("outgame.txt","a");
        while(!feof(xxorderout)){
            fflush(stdin);
            fgets(xxx,106,xxorderout);
            fflush(stdin);
            fprintf(outgame,"%s",xxx);
            //printf("\n%s",xxx);
        }
        fclose(outgame);
    }
    else{}
    fclose(xxorderout);

    Time minn,maxx,avgg;                //สร้าง struct เพื่อเก็บค่าเวลา ในการเล่นแต่ละรอบ
    float maxxx=-999,minnn=999;          //ในกรณเล่นไม่จบ
    int jj;

    int bank;
    char cnn[3],bbc[3],pbs[3],tnn[3];
    char pon[120][4];// เปลื่อนตัวเลขเป็นตัวหนังสือกรณีตอบถูก
    pon[57][0]='5';
    pon[57][1]='7';
    pon[57][2]=' ';
    pon[57][3]=' ';
    pon[57][4]='\0';

    pon[58][0]='5';
    pon[58][1]='8';
    pon[58][2]=' ';
    pon[58][3]=' ';
    pon[58][4]='\0';

    pon[59][0]='5';
    pon[59][1]='9';
    pon[59][2]=' ';
    pon[59][3]=' ';
    pon[59][4]='\0';

    pon[60][0]='6';
    pon[60][1]='0';
    pon[60][2]=' ';
    pon[60][3]=' ';
    pon[60][4]='\0';

    pon[61][0]='6';
    pon[61][1]='1';
    pon[61][2]=' ';
    pon[61][3]=' ';
    pon[61][4]='\0';

    pon[62][0]='6';
    pon[62][1]='2';
    pon[62][2]=' ';
    pon[62][3]=' ';
    pon[62][4]='\0';

    pon[63][0]='6';
    pon[63][1]='3';
    pon[63][2]=' ';
    pon[63][3]=' ';
    pon[63][4]='\0';

    pon[64][0]='6';
    pon[64][1]='4';
    pon[64][2]=' ';
    pon[64][3]=' ';
    pon[64][4]='\0';

    pon[65][0]='6';
    pon[65][1]='5';
    pon[65][2]=' ';
    pon[65][3]=' ';
    pon[65][4]='\0';

    pon[66][0]='6';
    pon[66][1]='6';
    pon[66][2]=' ';
    pon[66][3]=' ';
    pon[66][4]='\0';

    pon[67][0]='6';
    pon[67][1]='7';
    pon[67][2]=' ';
    pon[67][3]=' ';
    pon[67][4]='\0';

    pon[68][0]='6';
    pon[68][1]='8';
    pon[68][2]=' ';
    pon[68][3]=' ';
    pon[68][4]='\0';

    pon[69][0]='6';
    pon[69][1]='9';
    pon[69][2]=' ';
    pon[69][3]=' ';
    pon[69][4]='\0';

    pon[70][0]='7';
    pon[70][1]='0';
    pon[70][2]=' ';
    pon[70][3]=' ';
    pon[70][4]='\0';

    pon[71][0]='7';
    pon[71][1]='1';
    pon[71][2]=' ';
    pon[71][3]=' ';
    pon[71][4]='\0';

    pon[89][0]='8';
    pon[89][1]='9';
    pon[89][2]=' ';
    pon[89][3]=' ';
    pon[89][4]='\0';

    pon[90][0]='9';
    pon[90][1]='0';
    pon[90][2]=' ';
    pon[90][3]=' ';
    pon[90][4]='\0';

    pon[91][0]='9';
    pon[91][1]='1';
    pon[91][2]=' ';
    pon[91][3]=' ';
    pon[91][4]='\0';

    pon[92][0]='9';
    pon[92][1]='2';
    pon[92][2]=' ';
    pon[92][3]=' ';
    pon[92][4]='\0';

    pon[93][0]='9';
    pon[93][1]='3';
    pon[93][2]=' ';
    pon[93][3]=' ';
    pon[93][4]='\0';

    pon[94][0]='9';
    pon[94][1]='4';
    pon[94][2]=' ';
    pon[94][3]=' ';
    pon[94][4]='\0';

    pon[95][0]='9';
    pon[95][1]='5';
    pon[95][2]=' ';
    pon[95][3]=' ';
    pon[95][4]='\0';

    pon[96][0]='9';
    pon[96][1]='6';
    pon[96][2]=' ';
    pon[96][3]=' ';
    pon[96][4]='\0';

    pon[97][0]='9';
    pon[97][1]='7';
    pon[97][2]=' ';
    pon[97][3]=' ';
    pon[97][4]='\0';

    pon[98][0]='9';
    pon[98][1]='8';
    pon[98][2]=' ';
    pon[98][3]=' ';
    pon[98][4]='\0';

    pon[99][0]='9';
    pon[99][1]='9';
    pon[99][2]=' ';
    pon[99][3]=' ';
    pon[99][4]='\0';

    pon[100][0]='1';
    pon[100][1]='0';
    pon[100][2]='0';
    pon[100][3]=' ';
    pon[100][4]='\0';

    pon[101][0]='1';
    pon[101][1]='0';
    pon[101][2]='1';
    pon[101][3]=' ';
    pon[101][4]='\0';

    pon[102][0]='1';
    pon[102][1]='0';
    pon[102][2]='2';
    pon[102][3]=' ';
    pon[102][4]='\0';

    pon[103][0]='1';
    pon[103][1]='0';
    pon[103][2]='3';
    pon[103][3]=' ';
    pon[103][4]='\0';




    while (out==0){
        clock_t timei;         // เวลาของผู้เล่น
        timei = clock();             // ‡√‘Ë¡®—∫‡«≈“¢ÕßºŸÈ‡≈Ëπ

        srand(time(NULL));              //random แบบทำให้ค่านั้นไมซ้ำกัน
        ran=rand()%118;                  // randim 0-118
        rann=ran;
        table(rann);                     // ส่งไปยังฟังชั้น tableเพื่อ print ตาราง ออกมา



        printf("               ");
        textcolor(15,4);
        for (bank=57;bank<72;bank++){
            printf("%c",pon[bank][0]);
            printf("%c",pon[bank][1]);
            printf("%c",pon[bank][2]);
            printf("%c",pon[bank][3]);
        }
        printf("\n");
        resetcolor();
        printf("               ");
        textcolor(15,13);
        for (bank=89;bank<104;bank++){
            printf("%c",pon[bank][0]);
            printf("%c",pon[bank][1]);
            printf("%c",pon[bank][2]);
            printf("%c",pon[bank][3]);
        }
        printf("\n");
        resetcolor();
        printf("********************************************************************************\n");




                    //  ถ้าค่าที่ random ค่าที่ธาตุมีตัวเดียวจะ เข้า if ถ้าไม่ใช้ จะเข้า else
        if (rann==1||rann==5||rann==6||rann==7||rann==8||rann==9||rann==15||rann==16||rann==19||rann==23||rann==39||rann==53||rann==92){
            if(check==1){           // จะเช็คว่า ค่าcheck=1 หรือป่าว ถ้าใช่จะเข้าลูปนี้
                fw(&rann,&bbc);
                              // จะไปเข้า ฟังชัน fw() เพื่อ พิมพ์ตัวหนังสืออกมา ให้เรานั้นพิมพ์เลข อะตอมเพื่อตอบ
                //printf("\n\n\n%c",bbc[0]);

                scanf("%d",&innum);
                if (innum==rann){               //  ถ้า ค่าที่เราตอบ เท่ากับค่า random จะเป็นจริง
                    printf("True\n");
                    score[i]=1;
                    check=1;
                    if(ran==92){
                        pon[ran][0]=bbc[0];
                    }
                }
                else{
                    printf("False\n");
                    score[i]=0;
                    check=0;
                }
            }
            else{                                                            // ถ้าครั้งแรก หรือ ครั้งที่เรานั้นตอบไม่ถูกจะเข้า ลูปนี้ เพื่อให้เราตอบ
                printf("input Periodic Table Number: %d\n",rann);       //ramdom
                scanf("%s",&im);                                                // รับค่าจากผู้เล่นเกมส์
                fx(&imm,rann);
                                                                 // ส่งไปให้ฟังชัน fx() เพื่อ ไปเอาตัวหนังสืือมาเช็ค ว่าเหมือนกับที่เรานั้นตอบหรือไม่
                //printf("%c",imm[0]);
                cnn[0]=imm[0];    /////

                ascii a,b;                                   //สร้าง struct เพื่อสร้างตัวแปรประเภท int เพื่อเอา ค่าที่เรานั้นพิมพ์มา ไปเช็คว่าถูกต้องหรือไม่
                fascii(&im,&a.as);       //ส่งไปปยังฟังชัน ascii เพื่อไปแปลง จากตัวหนังสือไปเป็นตัว
                fascii(&imm,&b.as);      //เพราะว่า char เปรื่ยบเทียบ char ไม่ได้
                if (a.as==b.as){
                    printf("True\n");
                    score[i]=1;         // ถ้าเราตอบถูกจะให้คะแนน นั้นเป็น 1
                    check=1;
                    if(ran==92){
                        pon[ran][0]=imm[0];
                    }
                }
                else{
                    printf("False\n");
                    score[i]=0;
                    check=0;
                }
            }
        }
        else {
            if(check==1){
                fww(&rann,&pbs,&tnn);
                scanf("%d",&innum);

                //printf("\n\n\n%c%c",pbs[0],tnn[0]);

                if (innum==rann){
                    printf("True\n");
                    score[i]=1;
                    check=1;

                    if(rann==57||rann==58||rann==59||rann==60||rann==61||rann==62||rann==63||rann==64||rann==65||rann==66||rann==67||rann==68||rann==69||rann==70||rann==71||rann==89||rann==90||rann==91||rann==92||rann==93||rann==94||rann==95||rann==96||rann==97||rann==98||rann==99||rann==100||rann==101||rann==102||rann==103){
                        if(rann==100||rann==101||rann==102||rann==103){
                            pon[rann][0]=pbs[0];
                            pon[rann][1]=tnn[0];
                            pon[rann][2]=' ';
                        }
                        else{
                            pon[rann][0]=pbs[0];
                            pon[rann][1]=tnn[0];
                        }

                    }
                }
                else{
                    printf("False\n");
                    score[i]=0;
                    check=0;
                }
            }
            else{
                printf("input Periodic Table Number: %d\n",rann);//ramdom
                scanf("%s",in);//2
                fy(&m,&mm,rann);


                //printf("\n\n%c%c",m[0],mm[0]);

                //printf("\n\n%s%s\n",m,mm);
                //printf("\n\n%c%c\n",in[0],in[1]);
                ascii a,b,c,d;  // in,m,in1,mm
                fascii(&in[0],&a.as); //pas 8 for in1
                fascii(&m,&b.as);     //pas 8 for m
                fascii(&in[1],&c.as);
                fascii(&mm,&d.as);
                if((a.as==b.as)&&(c.as==d.as)){
                    printf("True\n");
                    score[i]=1;
                    check=1;
                    if(rann==57||rann==58||rann==59||rann==60||rann==61||rann==62||rann==63||rann==64||rann==65||rann==66||rann==67||rann==68||rann==69||rann==70||rann==71||rann==89||rann==90||rann==91||rann==92||rann==93||rann==94||rann==95||rann==96||rann==97||rann==98||rann==99||rann==100||rann==101||rann==102||rann==103){
                        if(rann==100||rann==101||rann==102||rann==103){
                            pon[rann][0]=m[0];
                            pon[rann][1]=mm[0];
                            pon[rann][2]=' ';
                        }
                        else{
                            pon[rann][0]=m[0];
                            pon[rann][1]=mm[0];
                        }
                    }
                }
                else{
                    printf("False\n");
                    score[i]=0;
                    check=0;
                }
            }
        }

        num=num+1;          //เอาไว้นับรอบ

        timei = clock() - timei;        //เวลาของผู้เล่นในแต่ละรอบ
        double timei_taken = ((double)timei)/CLOCKS_PER_SEC;
        itime[i] = timei_taken; //เก็บเวลาของผู้เล่นในแต่ละรอบไว้ใน itime[i] ตัวแปรอาเรย์  เพื่อหาค่า  time min max avg num  ต่อไป
        //printf("%.2f\t",itime[i]);

        timenum=timenum+itime[i];       // บวกเวลาของผู้เล่นแต่ละรอบ ไว้ใรกรณีผู้เล่นออกจากเกมส์ก่อนเล่นจบ
        for (jj=0;jj<num;jj++){         // หาค่า min max avg ของการเล่นในแต่ละรอบ เอาไว้ในกรรณีผู้เล่นออกจารเกมส์(แต่ยังเล่นไม่จบ)
            if(itime[jj]<minnn){
                minnn=itime[jj];
            }
        }
        for (jj=0;jj<num;jj++){
            if(itime[jj]>maxxx){
                maxxx=itime[jj];
            }
        }
        minn.timee=minnn;
        maxx.timee=maxxx;
        avgg.timee=(timenum/num);
        ////printf("%.2f\n",minn.timee);
        //printf("%.2f\n",maxx.timee);
        t.score=0;
        f.score=0;
        for (jj=0;jj<num;jj++){
            if (score[jj]==1){
                t.score=t.score+1;
            }
            else {
                f.score=f.score+1;
            }
        }
        //เปิดไฟล์ เพื่อเก็บค่าในกรณีที่ผู้เล่นออกจากเกมส์ก่อน (กรณีผู้เล่นเล่นไม่จบและออกจากเกมส์)
        xxorderout=fopen("xxorderout.txt","w");
        fprintf(xxorderout,"\n      %d",oorder);
        fprintf(xxorderout,"\t\t%s",name);
        fprintf(xxorderout,"\t    %d\t    %d",t.score,f.score);
        fprintf(xxorderout,"\t   %.2f",oavg);
        fprintf(xxorderout,"\t     %d",num);
        fprintf(xxorderout,"\t   %.2f",timenum);
        fprintf(xxorderout,"\t   %.2f",minn.timee);
        fprintf(xxorderout,"\t   %.2f",maxx.timee);
        fprintf(xxorderout,"\t   %.2f",avgg.timee);
        fprintf(xxorderout,"\t\tNot Finish ");
        fclose(xxorderout);
        //ถ้าผู้เล่นจกเล่นต่อให้พิมพ์ 0 เพื่อเล่นต่อ หรือพิมพ์เลขอื่น เพื่อ ออกจากเกมส์ และจะโชว์ค่าต่างๆที่ผู้เล่นนั้นทำได้
        printf("Type Any number that is not 0 out\n");
        scanf("%d",&out);
        system("CLS");  //ล้างหน้งจอทั้งหมด
        i=i+1;      //เอาไว้นับรอบ

    }
    // เอาไว้สำหรับผู้เล่นนั้น เล่นจบเกมส์ มันจะล้างค่าที่โปรแกรมนั้นบรรทึกข้อมูลไว้ในไฟล์ ในการเก็บข้อมูลในการณีที่ผู้เล่นนั้นเล่นไม่จบ
    xxorderout=fopen("xxorderout.txt","w");
    fclose(xxorderout);
    // เอาไว้แก้ไขข้อมูลในไฟล์ในการที่ผู้เล่นนั้นเล่นไม่จบ (ลำดับของผู้เล่นที่เล่นไมาจบ)
    k=0;
    forderr(&k);
    // เอาไว้โชว์ คะแนนที่ผู้เล่นนั้นทำได้ในการเล่นนั้นแต่ละครั้ง
    printf("TrueFalse ALL:");
    tru.score=0;
    fals.score=0;
    for (j=0;j<num;j++){
        printf("%d",score[j]);
        if (score[j]==1){
            tru.score=tru.score+1;
        }
        else {
            fals.score=fals.score+1;
        }
    }
    // เอาไว้หา ผู้เล่นนั้นเล่นไปกี่ครั้ง
    for (j=0;j<num;j++){
         numavg=numavg+score[j];
    }

    avg=tru.score/num;      // หาค่าเฉลื่ยที่ผู้เล่นนั้นทำได้ (กรณีที่ตอบถูก)

    printf ("\n");
    printf("Point True: %d\n",tru.score);
    printf("Point False: %d\n",fals.score);
    printf("Point Avg: %.2f\n",avg);
    printf("Point : %d\n",num);

    // หาค่าเวลาต่องๆที่เรานั้นทำได้
    Time timemin,timemax,timeavg,timeall;
    timemax.timee=0;
    float max=-999,min=999;
    for (j=0;j<num;j++){
        if(itime[j]<min){
            min=itime[j];
            timemin.timee=min;
        }
    }
    for (j=0;j<num;j++){
        if(itime[j]>max){
            max=itime[j];
            timemax.timee=max;
        }
    }

    //ti = clock() - ti;
    //double timeee = ((double)ti)/CLOCKS_PER_SEC;

    // สร้างตัวแปรที่เอาไว้สำหรับที่ผู้เล่นนั้น เล่นไปในแต่ละครั้งเอามารวมกัน
    double  timeee;
    for (j=0;j<num;j++){
        timeee=timeee+itime[j];
    }
    timeall.timee = timeee;                     //time all
    //printf("%.2f",timeee);

    timeavg.timee=(timeall.timee/num);
    printf ("\nTime all %.2f",timeall.timee);                   //time all
    printf ("\nTime min %.2f",timemin.timee);
    printf ("\nTime max %.2f",timemax.timee);
    printf ("\nTime avg %.2f",timeavg.timee);
    or(&order);             // ส่งไฟยังฟังชัน or() เพื่อหาลำดับของผู้เล่น

    //ทึงข้อมูลต่างๆลงไปในไฟล์
    game=fopen("game.txt","a");
    fprintf(game,"\n      %d",order);
    fprintf(game,"\t\t%s",name);
    fprintf(game,"\t    %d\t    %d",tru.score,fals.score);
    fprintf(game,"\t   %.2f",avg);
    fprintf(game,"\t     %d",num);
    fprintf(game,"\t   %.2f",timeall.timee);
    fprintf(game,"\t   %.2f",timemin.timee);
    fprintf(game,"\t   %.2f",timemax.timee);
    fprintf(game,"\t   %.2f",timeavg.timee);
    fprintf(game,"\t\tFinish ");
    fflush(stdin);
    fclose(game);
    return 0;
}
void fx(char*nn,int ss){
    //printf("\n%d",ss);//random
    switch (ss){
        case 1:*nn='H'; break;
        case 5:*nn='B'; break;
        case 6:*nn='C'; break;
        case 7:*nn='N'; break;
        case 8:*nn='O'; break;
        case 9:*nn='F'; break;
        case 15:*nn='P'; break;
        case 16:*nn='S'; break;
        case 19:*nn='K'; break;
        case 23:*nn='V'; break;
        case 39:*nn='Y'; break;
        case 53:*nn='I'; break;
        case 92:*nn='U'; break;
    }
}
void fy(char*m,char*mm,int ss){
    //printf("\n%d",ss);
    switch (ss){
        case 2: *m='H';
                *mm='e';
                break;
        case 3: *m='L';
                *mm='i';
                break;
        case 4: *m='B';
                *mm='e';
                break;
        case 10:*m='N';
                *mm='e';
                break;
        case 11:*m='N';
                *mm='a';
                break;
        case 12:*m='M';
                *mm='g';
                break;
        case 13:*m='A';
                *mm='l';
                break;
        case 14:*m='S';
                *mm='i';
                break;
        case 17:*m='C';
                *mm='l';
                break;
        case 18:*m='A';
                *mm='r';
                break;
        case 20:*m='C';
                *mm='a';
                break;
        case 21:*m='S';
                *mm='c';
                break;
        case 22:*m='T';
                *mm='i';
                break;
        case 24:*m='C';
                *mm='r';
                break;
        case 25:*m='M';
                *mm='n';
                break;
        case 26:*m='F';
                *mm='e';
                break;
        case 27:*m='C';
                *mm='o';
                break;
        case 28:*m='N';
                *mm='i';
                break;
        case 29:*m='C';
                *mm='u';
                break;
        case 30:*m='Z';
                *mm='n';
                break;
        case 31:*m='G';
                *mm='a';
                break;
        case 32:*m='G';
                *mm='e';
                break;
        case 33:*m='A';
                *mm='s';
                break;
        case 34:*m='S';
                *mm='e';
                break;
        case 35:*m='B';
                *mm='r';
                break;
        case 36:*m='K';
                *mm='r';
                break;
        case 37:*m='R';
                *mm='b';
                break;
        case 38:*m='S';
                *mm='r';
                break;
        case 40:*m='Z';
                *mm='r';
                break;
        case 41:*m='N';
                *mm='b';
                break;
        case 42:*m='M';
                *mm='o';
                break;
        case 43:*m='T';
                *mm='c';
                break;
        case 44:*m='R';
                *mm='u';
                break;
        case 45:*m='R';
                *mm='h';
                break;
        case 46:*m='P';
                *mm='d';
                break;
        case 47:*m='A';
                *mm='g';
                break;
        case 48:*m='C';
                *mm='d';
                break;
        case 49:*m='I';
                *mm='n';
                break;
        case 50:*m='S';
                *mm='n';
                break;
        case 51:*m='S';
                *mm='b';
                break;
        case 52:*m='T';
                *mm='e';
                break;
        case 54:*m='X';
                *mm='e';
                break;
        case 55:*m='C';
                *mm='s';
                break;
        case 56:*m='B';
                *mm='a';
                break;
        case 57:*m='L';
                *mm='a';
                break;
        case 58:*m='C';
                *mm='e';
                break;
        case 59:*m='P';
                *mm='r';
                break;
        case 60:*m='N';
                *mm='d';
                break;
        case 61:*m='P';
                *mm='m';
                break;
        case 62:*m='S';
                *mm='m';
                break;
        case 63:*m='E';
                *mm='u';
                break;
        case 64:*m='G';
                *mm='d';
                break;
        case 65:*m='T';
                *mm='b';
                break;
        case 66:*m='D';
                *mm='y';
                break;
        case 67:*m='H';
                *mm='o';
                break;
        case 68:*m='E';
                *mm='r';
                break;
        case 69:*m='T';
                *mm='m';
                break;
        case 70:*m='Y';
                *mm='b';
                break;
        case 71:*m='L';
                *mm='u';
                break;
        case 72:*m='H';
                *mm='f';
                break;
        case 73:*m='T';
                *mm='a';
                break;
        case 75:*m='R';
                *mm='e';
                break;
        case 76:*m='O';
                *mm='s';
                break;
        case 77:*m='I';
                *mm='r';
                break;
        case 78:*m='P';
                *mm='t';
                break;
        case 79:*m='A';
                *mm='u';
                break;
        case 80:*m='H';
                *mm='g';
                break;
        case 81:*m='T';
                *mm='l';
                break;
        case 82:*m='P';
                *mm='b';
                break;
        case 83:*m='B';
                *mm='i';
                break;
        case 84:*m='P';
                *mm='o';
                break;
        case 85:*m='A';
                *mm='t';
                break;
        case 86:*m='R';
                *mm='n';
                break;
        case 87:*m='F';
                *mm='r';
                break;
        case 88:*m='R';
                *mm='a';
                break;
        case 89:*m='A';
                *mm='C';
                break;
        case 90:*m='T';
                *mm='h';
                break;
        case 91:*m='P';
                *mm='a';
                break;
        case 93:*m='N';
                *mm='p';
                break;
        case 94:*m='P';
                *mm='u';
                break;
        case 95:*m='A';
                *mm='m';
                break;
        case 96:*m='C';
                *mm='m';
                break;
        case 97:*m='B';
                *mm='k';
                break;
        case 98:*m='C';
                *mm='f';
                break;
        case 99:*m='E';
                *mm='s';
                break;
        case 100:*m='F';
                *mm='m';
                break;
        case 101:*m='M';
                *mm='d';
                break;
        case 102:*m='N';
                *mm='o';
                break;
        case 103:*m='L';
                *mm='r';
                break;
        case 104:*m='R';
                *mm='f';
                break;
        case 105:*m='D';
                *mm='b';
                break;
        case 106:*m='S';
                *mm='g';
                break;
        case 107:*m='B';
                *mm='h';
                break;
        case 108:*m='H';
                *mm='s';
                break;
        case 109:*m='M';
                *mm='t';
                break;
        case 110:*m='D';
                *mm='s';
                break;
        case 111:*m='R';
                *mm='g';
                break;
        case 112:*m='C';
                *mm='n';
                break;
        case 113:*m='N';
                *mm='h';
                break;
        case 114:*m='f';
                *mm='l';
                break;
        case 115:*m='M';
                *mm='c';
                break;
        case 116:*m='L';
                *mm='v';
                break;
        case 117:*m='T';
                *mm='s';
                break;
        case 118:*m='O';
                *mm='g';
                break;
    }
}
void fascii(char *dd,int *a){    // ascii pas 8
    //printf("%c",*dd);
    //*a=0000;
    switch (*dd){
        case 'A': *a=101; break;
        case 'B': *a=102; break;
        case 'C': *a=103; break;
        case 'D': *a=104; break;
        case 'E': *a=105; break;
        case 'F': *a=106; break;
        case 'G': *a=107; break;
        case 'H': *a=110; break;
        case 'I': *a=111; break;
        case 'J': *a=112; break;
        case 'K': *a=113; break;
        case 'L': *a=114; break;
        case 'M': *a=115; break;
        case 'N': *a=116; break;
        case 'O': *a=117; break;
        case 'P': *a=120; break;
        case 'Q': *a=121; break;
        case 'R': *a=122; break;
        case 'S': *a=123; break;
        case 'T': *a=124; break;
        case 'U': *a=125; break;
        case 'V': *a=126; break;
        case 'W': *a=127; break;
        case 'X': *a=130; break;
        case 'Y': *a=131; break;
        case 'Z': *a=132; break;
        case 'a': *a=141; break;
        case 'b': *a=142; break;
        case 'c': *a=143; break;
        case 'd': *a=144; break;
        case 'e': *a=145; break;
        case 'f': *a=146; break;
        case 'g': *a=147; break;
        case 'h': *a=150; break;
        case 'i': *a=151; break;
        case 'j': *a=152; break;
        case 'k': *a=153; break;
        case 'l': *a=154; break;
        case 'm': *a=155; break;
        case 'n': *a=156; break;
        case 'o': *a=157; break;
        case 'p': *a=160; break;
        case 'q': *a=161; break;
        case 'r': *a=162; break;
        case 's': *a=163; break;
        case 't': *a=164; break;
        case 'u': *a=165; break;
        case 'v': *a=165; break;
        case 'w': *a=167; break;
        case 'x': *a=170; break;
        case 'y': *a=171; break;
        case 'z': *a=172; break;
        default : break;
    }
        //printf("%d",*a);
        return ;
}
void table(int rann){
    textcolor(15,10 );
    printf("1  ");
    resetcolor();
    printf("                                                                    ");
    textcolor(15,1 );
    printf("2  \n");
    resetcolor();
    textcolor(0,14 );
    printf("3  ");
    resetcolor();
    textcolor(15,6 );
    printf("4  ");
    resetcolor();
    printf("                                             ");
    textcolor(15,2 );
    printf("5   ");
    resetcolor();
    textcolor(15,10 );
    printf("6   7   8   ");
    resetcolor();
    textcolor(0,11 );
    printf("9   ");
    resetcolor();
    textcolor(15,1 );
    printf("10 \n");
    resetcolor();

    textcolor(0,14 );
    printf("11 ");
    resetcolor();
    textcolor(15,6 );
    printf("12 ");
    resetcolor();
    printf("                                             ");
    textcolor(15,3 );
    printf("13  ");
    resetcolor();
    textcolor(15,2 );
    printf("14  ");
    resetcolor();
    textcolor(15,10 );
    printf("15  16  ");
    resetcolor();
    textcolor(0,11 );
    printf("17  ");
    resetcolor();
    textcolor(15,1 );
    printf("18 \n");
    resetcolor();

    textcolor(0,14 );
    printf("19 ");
    resetcolor();
    textcolor(15,6 );
    printf("20 ");
    resetcolor();
    textcolor(15,5 );
    printf("21       22  23  24  25  26  27  28  29  30  ");
    resetcolor();
    textcolor(15,3 );
    printf("31  ");
    resetcolor();
    textcolor(15,2 );
    printf("32  33  ");
    resetcolor();
    textcolor(15,10 );
    printf("34  ");
    resetcolor();
    textcolor(0,11 );
    printf("35  ");
    resetcolor();
    textcolor(15,1 );
    printf("36 \n");
    resetcolor();

    textcolor(0,14 );
    printf("37 ");
    resetcolor();
    textcolor(15,6 );
    printf("38 ");
    resetcolor();
    textcolor(15,5 );
    printf("39       40  41  42  43  44  45  46  47  48  ");
    resetcolor();
    textcolor(15,3 );
    printf("49  50  ");
    resetcolor();
    textcolor(15,2 );
    printf("51  52  ");
    resetcolor();
    textcolor(0,11 );
    printf("53  ");
    resetcolor();
    textcolor(15,1);
    printf("54 \n");
    resetcolor();

    textcolor(0,14);
    printf("55 ");
    resetcolor();
    textcolor(15,6);
    printf("56 ");
    resetcolor();
    textcolor(15,4);
    printf("[57-71]  ");
    resetcolor();
    textcolor(15,5);
    printf("72  73  74  75  76  77  78  79  80  ");
    resetcolor();
    textcolor(15,3);
    printf("81  82  83  ");
    resetcolor();
    textcolor(15,2);
    printf("84  ");
    resetcolor();
    textcolor(0,11);
    printf("85  ");
    resetcolor();
    textcolor(15,1);
    printf("86 \n");
    resetcolor();

    textcolor(0,14);
    printf("87 ");
    resetcolor();
    textcolor(15,6);
    printf("88 ");
    resetcolor();
    textcolor(15,13);
    printf("[89-103] ");
    resetcolor();
    textcolor(15,5);
    printf("104 105 106 107 108 109 110 111 112 ");
    resetcolor();
    textcolor(15,3);
    printf("113 114 115 116 ");
    resetcolor();
    textcolor(0,11);
    printf("117 ");
    resetcolor();
    textcolor(15,1);
    printf("118\n");
    resetcolor();
    printf("\n");

   // printf("               ");
   // textcolor(15,4);
   // printf("57  58  59  60  61  62  63  64  65  66  67  68  69  70  71 \n");
   // resetcolor();

   // printf("               ");
   // textcolor(15,13);
    //printf("89  90  91  92  93  94  95  96  97  98  99  100 101 102 103\n");
   // resetcolor();
   // printf("********************************************************************************\n");


    //printf("1                                                                      2\n");
    //printf("3  4                                               5   6   7   8   9   10\n");
    //printf("11 12                                              13  14  15  16  17  18\n");
    //printf("19 20 21       22  23  24  25  26  27  28  29  30  31  32  33  34  35  36\n");
    //printf("37 38 39       40  41  42  43  44  45  46  47  48  49  50  51  52  53  54\n");
    //printf("55 56 [57-71]  72  73  74  75  76  77  78  79  80  81  82  83  84  85  86\n");
    //printf("87 88 [89-103] 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118\n");
    //printf("\n");
    //printf("               57  58  59  60  61  62  63  64  65  66  67  68  69  70  71\n");
    //printf("               89  90  91  92  93  94  95  96  97  98  99  100 101 102 103\n");
    //printf("********************************************************************************\n");
}
void fw(int *ran,char *tnt){
    char xxx[2];
    int rann=*ran;
    fx(&xxx,rann);
    //printf("11111111111111111\n\n");
    printf("input Periodic Table Number: %c\n",xxx[0]);
    *tnt=xxx[0];
    //printf("%s",xxx);
}
void fww(int *ran,char*ty,char*tu){
    char x[2],xx[2];
    int rann=*ran;
    fy(&x,&xx,rann);
    printf("input Periodic Table Number: %c%c\n",x[0],xx[0]);
    *ty=x[0];
    *tu=xx[0];

}

void or(int *order){
    FILE *a;
    int x;
    a=fopen("Order.txt","r");
    fflush(stdin);
    fscanf(a,"%d",&x);
    //printf("%d",x);
    fclose(a);
    *order=x;
    a=fopen("Order.txt","w");
    fflush(stdin);
    x=x+1;
    fprintf(a,"%d",x);
    fclose(a);

}

fgame(){
    int g,l;
    printf("Press 1 to see how to play. \n");
    printf("Pressing 2 will remove all scores and time in the game.\n");
    printf("Press any number that is not 1 or 2 to play the game.\n");
    printf("Please enter the number: \n");
    scanf("%d",&g);
    if (g==1){
        system("CLS");
        printf("1.Let us type a name\n");
        printf("2.Let us type the atomic or Symbol\n");
        printf("3.Type any number to play the game.\n");

        printf("\n\nPlease type numbers: ");
        scanf("%d",&l);
        system("CLS");   //≈È“ßÀπÈ“®Õ
    }
    else if(g==2){      //≈È“ß§Ë“∑’Ë∑”‰¥È∑—ÈßÀ¡¥
        FILE *deletegame,*deleteOrder;
        deletegame=fopen("game.txt","w");
        fprintf(deletegame,"_________________________________________________________________________________________________________\n");
        fprintf(deletegame,"|Order	|	Name	|	Score	    \t\t|		Time		|	Status      |\n");
        fprintf(deletegame,"|	|		|  True	|  False	|   avg     |   num   |   All	|   Min	|  Max	|  avg	|		 |\n");
        fprintf(deletegame,"|________________________________________________________________________________________________________|\n");
        fclose(deletegame);

        deleteOrder=fopen("Order.txt","w");
        int a=1;
        fprintf(deleteOrder,"%d",a);
        fclose(deleteOrder);

        FILE *outgame,*xxorderout,*orderout;
        outgame=fopen("outgame.txt","w");
        fprintf(outgame,"_________________________________________________________________________________________________________\n");
        fprintf(outgame,"|Order	|	Name	|	Score	    \t\t|		Time		|	Status      |\n");
        fprintf(outgame,"|	|		|  True	|  False	|   avg     |   num   |   All	|   Min	|  Max	|  avg	|		 |\n");
        fprintf(outgame,"|________________________________________________________________________________________________________|\n");
        fclose(outgame);

        xxorderout=fopen("xxorderout.txt","w");
        fclose(xxorderout);

        orderout=fopen("orderout.txt","w");
        fprintf(orderout,"%d",a);
        fclose(orderout);

    }
    system("CLS");
    return 0;
}
forderr(int*k){
    FILE *aa;
    int x,xy=99;
    aa=fopen("orderout.txt","r");
    fflush(stdin);
    fscanf(aa,"%d",&x);
    //printf("%d",x);
    fclose(aa);
    aa=fopen("orderout.txt","w");
    fflush(stdin);
    if (xy==*k){
        x=x+1;
        fprintf(aa,"%d",x);
        fclose(aa);
    }
    else{
        x=x-1;
        fprintf(aa,"%d",x);
        fclose(aa);
    }

    return 0;
}
